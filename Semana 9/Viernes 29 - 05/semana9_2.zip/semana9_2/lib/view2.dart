import 'package:flutter/material.dart';

class view2 extends StatelessWidget {
  const view2({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.pinkAccent,
      ),
      body: Column(
        children: [
          Container(
            height: 170,
            width: double.infinity,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.only(
                bottomRight: Radius.circular(50)
              ),
              color: Colors.pinkAccent
            ),
            child: Stack(
              children: [
                Positioned(
                    top: 10,
                    child: Container(
                      height: 80,
                      width: 300,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.only(
                          bottomRight: Radius.circular(20),
                        topRight: Radius.circular(20),
                        ),
                        color: Colors.white
                      ),
                    )),

                Positioned(
                    top: 30,
                    left: 15,
                    child: Text('PRODUCTOS 2026',style: TextStyle(
                      color: Colors.pinkAccent,
                      fontWeight: FontWeight.bold,
                      fontSize: 30
                    ),))
              ],
            ),
          ),

        ],
      )
    );
  }
}
