import 'package:flutter/material.dart';

class view1 extends StatefulWidget {
  const view1({super.key});

  @override
  State<view1> createState() => _view1State();
}

class _view1State extends State<view1> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.phone_android_outlined,
                size: 120,
              ),

              SizedBox(
                height: 30,
              ),

              Text('LOGIN USER', style: TextStyle(
                fontWeight: FontWeight.bold,
                  fontSize: 30
              ),),

              SizedBox(
                height: 30,
              ),

              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15)
                  ),
                  child:Padding(
                      padding: const EdgeInsets.all(12.0),
                  child: TextField(
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: 'Insert Mail',
                    ),
                  )
                ),
              ),
              ),

              SizedBox(
                height: 30,
              ),

              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Container(
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(15)
                    ),
                    child:Padding(
                        padding: const EdgeInsets.all(12.0),
                    child: TextField(
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: 'Insert Password',
                      ),
                    )
                ),
              ),
            ),


              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(backgroundColor:Colors.pinkAccent),
                        onPressed: (){} ,
                        child: Text('Iniciar Sesión', style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 17,
                          color: Colors.white
                        ),))
                    ),
                  ],
                ),
              ),

              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('Estas Registado? ', style:
                  TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold),),
                  Text('  Registrate ahora ', style:
                  TextStyle(
                      color: Colors.pinkAccent,
                      fontSize: 18,
                      fontWeight: FontWeight.bold),),
                ],
              )

            ],
        ),),
      )
    );
  }
}
